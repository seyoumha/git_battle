export class Player{

  constructor(public username: string = '', public avatar: string = '', public score: number = null){
  }
}
